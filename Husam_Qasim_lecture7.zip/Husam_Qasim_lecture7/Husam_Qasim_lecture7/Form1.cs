﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lecture7
{
    public partial class Form1 : Form
    {
        public static string staticvariable = "";
        public Form1()
        {
            InitializeComponent();
        }
        public Form1(string name)
        {
            InitializeComponent();

            this.Text = name;
        }
        Form2 objfll;




        public Form1(Form2 objectform2)
        {
            InitializeComponent();
            textBox1.Text =
            objectform2.getname();
            //textBox1.Text =objectform2.txtfom2.Text;
            objfll = objectform2;
        }
        public Form1(ListBox mylist)
        {
            InitializeComponent();
            listBox1 = mylist;
        }
        public void setvalue(string name)
        {
           textBox1.Text = name;
        }
        public string getvalue()
        { return textBox1.Text; }

        private void button2_Click(object sender, EventArgs e)
        {
            objfll.updatename(getvalue());
            // objfll.updatename(texform12.Text);
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
