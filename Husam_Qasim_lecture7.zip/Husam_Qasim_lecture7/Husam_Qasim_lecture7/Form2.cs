﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lecture7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public string getname()
        {
            return txtform2.Text;
        }
        public void updatename(string name)
        {
            txtform2.Text = name;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1("عرض اكثر من نافذة");
            f.ShowDialog();
            f.Show();

        }
        //Show with function
        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.setvalue(txtform2.Text); f.Show();
        }
        //Show with modifiers
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.textBox1.Text = txtform2.Text;
            f.Show();
        }
        //Show with staticvariable
        private void button5_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            Form1.staticvariable =
            txtform2.Text;
            f.Show();

        }
        //show without real object
        private void button6_Click(object sender, EventArgs e)
        {
            new Form1(txtform2.Text).Show();
        }
        //show and send listbox object
        private void button10_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1(listBox1);

            f.Show();

        }

        // show and semd this form
        private void button9_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1(this);
            f.Show();
        }
        //show onse
        Form1 formons = new Form1();
        private void button8_Click(object sender, EventArgs e)
        {
            formons.Show();
        }
        //show formal object 
        Form1 formalobject;
        private void button7_Click(object sender, EventArgs e)
        {
            if (formalobject== null ||formalobject.IsDisposed)
                {
                formalobject = new Form1();
                  //formalobject.textBox1.Text =txtform2.Text;
                formalobject.Show();
            }
            else
            { 
                // formalobject.setvalue(txtform2.Text) 
                formalobject.Show();
                 formalobject.Focus();
}

        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
